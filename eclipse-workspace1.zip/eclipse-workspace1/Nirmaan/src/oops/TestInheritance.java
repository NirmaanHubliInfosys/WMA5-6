package oops;

public class TestInheritance {
public static void main(String[] args) {
	Cat cat =new Cat();
	cat.animal();
	cat.dog();		
	cat.cat();
	}

}
