package oops;

public class ChildCar extends Parent{

	void childCar() {
		System.out.println("child purchase own car");
	}

}
