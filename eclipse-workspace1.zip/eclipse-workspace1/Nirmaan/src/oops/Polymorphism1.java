package oops;

public class Polymorphism1 {

	 public void method1(int number) {
		  System.out.println("method1 :" +number);
	  }
}
