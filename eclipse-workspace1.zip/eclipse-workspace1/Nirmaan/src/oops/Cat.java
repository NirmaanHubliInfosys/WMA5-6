package oops;

public class Cat extends Dog{
	void cat(){System.out.println("cat also eating...");}  
}
