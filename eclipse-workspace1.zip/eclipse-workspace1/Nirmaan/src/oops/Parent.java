package oops;

public class Parent {//parent class
	void run(){
		System.out.println("Parent is running");
		}  
}
