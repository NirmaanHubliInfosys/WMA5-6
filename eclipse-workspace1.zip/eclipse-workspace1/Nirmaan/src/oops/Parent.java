package oops;

public class Parent extends GrandParent{

	void education() {
		System.out.println("parent is educated...");
		}
	void ownHouse() {
	System.out.println("parent have own house...");
	}
}




