package oops;

public class Child extends Parent{

	void ownCar() {
		System.out.println("child have own car");
	}
	

}
