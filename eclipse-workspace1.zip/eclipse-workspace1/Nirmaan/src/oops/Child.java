package oops;

public class Child extends Parent{//child class

	  void run()
	  {
		  System.out.println("Child is running safely");
	  }
	  
	  public static void main(String args[]){  
		  Child obj = new Child();//creating object  
		  obj.run();//calling method  
		  } 
}
