package oops;

public class ParentChildRunner {

	public static void main(String[] args) {
		ChildCar child=new ChildCar();
		child.childCar();
		
	}

}
