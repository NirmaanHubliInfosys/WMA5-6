package oops;

public class Animal {
	void animal(){System.out.println("Animal eating...");}  
}
