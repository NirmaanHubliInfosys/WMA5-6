package oops;

public class GrandParent {

	void land() {
	System.out.println("Granparent have own land...");
}
}
