package oops;

public class Dog extends Animal{
	void dog(){System.out.println("dog is eating...");}  
}
