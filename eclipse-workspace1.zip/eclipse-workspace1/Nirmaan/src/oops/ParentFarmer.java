package oops;

public class ParentFarmer {

	void Parent() {
		System.out.println("parent is farmer");
	}
	void Land() {
		System.out.println("parent have own land:1 acr");
	}
}
