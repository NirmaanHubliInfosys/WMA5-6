package oops;

public class Polymorphism {

  public void method1(int number ,String name) {
	  System.out.println("method1 :" +number +" "+ name);
  }
  public void method1(int number) {
	  System.out.println("method1:"+number);
  }
	
}
