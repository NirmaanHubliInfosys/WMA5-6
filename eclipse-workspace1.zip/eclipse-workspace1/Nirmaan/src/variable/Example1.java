package variable;

public class Example1 {

	static int m=10;//static
	int m1=20;
	void method() {
		int n=90;//local variable 
	}
	
	
	public static void main(String[] args) {
		int data=50;//instance variable

	}

}
