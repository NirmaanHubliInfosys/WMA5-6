package variable;

public class Employee {
int empId;
double empSalary;
String empName;
int empMobileNo;
String empAddress;

public Employee() {}
public int getEmpId() {
	return empId;
}
public void setEmpId(int empId) {
	this.empId = empId;
}
public double getEmpSalary() {
	return empSalary;
}
public void setEmpSalary(double empSalary) {
	this.empSalary = empSalary;
}
public String getEmpName() {
	return empName;
}
public void setEmpName(String empName) {
	this.empName = empName;
}
public int getEmpMobileNo() {
	return empMobileNo;
}
public void setEmpMobileNo(int empMobileNo) {
	this.empMobileNo = empMobileNo;
}
public String getEmpAddress() {
	return empAddress;
}
public void setEmpAddress(String empAddress) {
	this.empAddress = empAddress;
}
}
