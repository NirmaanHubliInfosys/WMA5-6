package variable;

public class FinalVariableExample3 extends FinalVariableExample {

	public static void main(String[] args) {
	
		FinalVariableExample3 obj = new FinalVariableExample3();
		obj.show();

	}

}
