package variable;


		public class FinalVariableExample {
			
			static int a = 10;//final variable
			
			void show() {
//				final int a=20;
				System.out.println("a = " + a);
					
			}

//			public static void main(String[] args) {
//				
//				FinalVariableExample obj = new FinalVariableExample();
//				obj.show();
//				
//			}

		}


