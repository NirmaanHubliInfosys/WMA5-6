package variable;

public class FinalVariableExample1 {

	public static void main(String[] args) {
		
		FinalVariableExample obj = new FinalVariableExample();
		obj.show();
		
	}
}
