package exception;

public class ExtendsThread extends Thread {
	  public static void main(String[] args) {
		ExtendsThread thread = new ExtendsThread();
		 thread.start();
	    System.out.println("This code is outside of the thread");
	  }
	  public void run() {
		  
	    System.out.println("This code is running in a thread");
	    
	  }
	}
