package exception;

public class JavaException2 {

	public static void main(String[] args) {
		
		int arr[]=new int[5];// 5-1=4 array is always starts from 0th index to n-1
		arr[0]=10;
		arr[1]=20;
		arr[2]=30;
		arr[3]=40;
		arr[4]=50;
		System.out.println(arr[6]);
	}
}
