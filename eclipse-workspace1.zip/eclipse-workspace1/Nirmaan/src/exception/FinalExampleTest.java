package exception;

public class FinalExampleTest {  

    final int age = 18;  
    String name ="renuka";
    void display() {  
    int age1 = 55;
    name ="komal";    }        
    public static void main(String[] args) {     
    FinalExampleTest obj = new FinalExampleTest();  
    obj.display();  
    }  
}  
