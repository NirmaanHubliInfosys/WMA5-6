package exception;

public class Main extends Thread {
	
	  public static int amount = 1;//static 

	  public static void main(String[] args) {
		  
	    Main thread = new Main();
	    thread.start();
	    System.out.println(amount);
	    amount++;
	    System.out.println(amount);
	  }

	  public void run() {
	    amount++;
	  }
	}