package typecasting;

public class NarrowingTypeCating {

	public static void main(String[] args) {
	double d=176.88;
	long l=(long)d;
	int i=(int)l;

	System.out.println("before conversion:"+d);
	
	System.out.println("after conversion into long type:"+l);
	System.out.println("after conversion into int type:"+i);
	}
	

}
